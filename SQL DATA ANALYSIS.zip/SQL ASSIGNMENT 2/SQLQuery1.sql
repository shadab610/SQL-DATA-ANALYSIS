--1 Display the �FIRST_NAME� from Employee table using the alias name as Employee_name.

select first_name as 'Alias_Name' from EmployeeTable;

--2 Display �LAST_NAME� from Employee table in upper case.

select upper(last_name) as upper from EmployeeTable;

--3 Display unique values of DEPARTMENT from EMPLOYEE table.

select distinct department from EmployeeTable;--4 Display the first three characters of LAST_NAME from EMPLOYEE table.select substring(last_name,1,3) as substring from EmployeeTable;--5 Display the unique values of DEPARTMENT from EMPLOYEE table and prints its length.select  department ,len(department) as length  from EmployeeTable;--6 Display the FIRST_NAME and LAST_NAME from EMPLOYEE table into a single column AS FULL_NAME a space char should separate them.select concat(first_name,' ',last_name) as Full_Name  from EmployeeTable;--7 DISPLAY all EMPLOYEE details from the employee table order by FIRST_NAME Ascending.select *  from EmployeeTable order by first_name asc;--8. Display all EMPLOYEE details order by FIRST_NAME Ascending and DEPARTMENT Descending.select *  from EmployeeTable order by first_name asc,department desc;--9 Display details for EMPLOYEE with the first name as �VEENA� and �KARAN� from EMPLOYEE table.

select *  from EmployeeTable where first_name in ('Veena','Karan');

--10 Display details of EMPLOYEE with DEPARTMENT name as �Admin�.

select * from EmployeeTable where department = 'Admin';

--11 DISPLAY details of the EMPLOYEES whose FIRST_NAME contains �V�.

select *  from EmployeeTable where first_name like ('V%');

--12 DISPLAY details of the EMPLOYEES whose SALARY lies between 100000 and 500000.

select *  from EmployeeTable where salary between 100000 and 500000;

--13 Display details of the employees who have joined in Feb-2020.

select*  from EmployeeTable where datepart(year,joining_date)=2020 and month(joining_date)=2;

--14 Display employee names with salaries >= 50000 and <= 100000.

select *  from EmployeeTable where salary >= 50000 and salary <= 100000;

--16 DISPLAY details of the EMPLOYEES who are also Managers.

SELECT DISTINCT W.FIRST_NAME,T.Employee__title
FROM EmployeeTable W
INNER JOIN Employee_Title T
ON W.[Employee_id(PK)] = T.Employee_ref_id
AND T.Employee__title in ('Manager');

--17 DISPLAY duplicate records having matching data in some fields of a table.

select department,count(*)
from EmployeeTable
group by  department
having count(*)>1;

--18 Display only odd rows from a table.

SELECT * FROM EmployeeTable where [Employee_id(PK)] %2! = 0;

--19 Clone a new table from EMPLOYEE table.

select * into employees from EmployeeTable;

--20 DISPLAY the TOP 2 highest salary from a table.

select top 2 * from EmployeeTable order by salary desc;

--21. DISPLAY the list of employees with the same salary.

select distinct w.[Employee_id(PK)],w.first_name,w.salary
from EmployeeTable w, EmployeeTable w1
where w.salary = w1.salary
and w.[Employee_id(PK)] != w1.[Employee_id(PK)];

--22 Display the second highest salary from a table.

select max(salary) from EmployeeTable where salary !=(select max(salary) from EmployeeTable);

--23 Display the first 50% records from a table.

select top 50 percent *  from EmployeeTable;

--24. Display the departments that have less than 4 people in it.

SELECT Department, COUNT([Employee_id(PK)]) as  worker FROM EmployeeTable GROUP BY Department HAVING COUNT([Employee_id(PK)]) < 4;

--25. Display all departments along with the number of people in there.

SELECT DEPARTMENT, COUNT(DEPARTMENT) as 'Number of Workers' FROM EmployeeTable GROUP BY DEPARTMENT;

--26 Display the name of employees having the highest salary in each department.

SELECT w.DEPARTMENT,w.First_Name,w.Salary from(SELECT 
max(Salary) as TotalSalary,DEPARTMENT from EmployeeTable group by 
DEPARTMENT) as w1 
Inner Join EmployeeTable w on w1.DEPARTMENT=w.DEPARTMENT 
and w1.TotalSalary=w.Salary;

--27 Display the names of employees who earn the highest salary.

select * from EmployeeTable where salary = ( select max(salary) from EmployeeTable);

--28 Diplay the average salaries for each department.

select avg(salary) ,department from EmployeeTable group by department having count(department)>=1;

--29 display the name of the employee who has got maximum bonus.

SELECT DISTINCT W.FIRST_NAME,B.Bonus_amount
FROM EmployeeTable W
INNER JOIN Employees_Bonus B
ON W.[Employee_id(PK)] = B.[Employee_ref_id(FK)]
AND B.Bonus_Amount = (select max(Bonus_Amount)  from Employees_Bonus) ;

--30 Display the first name and title of all the employee.

select first_name, (department)as Title  from EmployeeTable;